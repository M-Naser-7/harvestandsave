/*
  # HarvestGuard Initial Schema

  ## Overview
  This migration sets up the core database structure for HarvestGuard, a food loss prevention
  system for Bangladesh farmers.

  ## New Tables
  
  ### `farmers`
  Stores farmer profile information with bilingual support
  - `id` (uuid, primary key) - Unique farmer identifier
  - `email` (text, unique) - Login email
  - `phone` (text) - Contact number
  - `name` (text) - Farmer's full name
  - `preferred_language` (text) - 'en' or 'bn' for English/Bangla
  - `division` (text) - Administrative division
  - `district` (text) - District location
  - `upazila` (text) - Sub-district for hyper-local weather
  - `achievement_points` (integer) - Gamification score
  - `created_at` (timestamptz) - Registration timestamp
  
  ### `crop_batches`
  Tracks individual harvested crop batches with storage details
  - `id` (uuid, primary key) - Unique batch identifier
  - `farmer_id` (uuid, foreign key) - References farmers table
  - `crop_type` (text) - Type of crop (initially 'paddy' or 'rice')
  - `estimated_weight` (numeric) - Weight in kilograms
  - `harvest_date` (date) - Date of harvest
  - `storage_location` (text) - Division/District location
  - `storage_type` (text) - Storage method (jute_bag, silo, open_area)
  - `status` (text) - 'active', 'completed', 'lost'
  - `actual_loss_kg` (numeric) - Actual loss recorded (nullable)
  - `created_at` (timestamptz) - Batch registration time
  
  ### `weather_cache`
  Caches weather data to reduce API calls
  - `id` (uuid, primary key)
  - `location_key` (text, unique) - Composite key: division-district-upazila
  - `forecast_data` (jsonb) - Weather forecast array
  - `fetched_at` (timestamptz) - Cache timestamp
  
  ### `risk_assessments`
  Stores calculated risk predictions and ETCL
  - `id` (uuid, primary key)
  - `batch_id` (uuid, foreign key) - References crop_batches
  - `risk_level` (text) - 'low', 'medium', 'high', 'critical'
  - `etcl_hours` (integer) - Estimated Time to Critical Loss in hours
  - `risk_factors` (jsonb) - Array of risk factor details
  - `advisory_bn` (text) - Bangla advisory message
  - `advisory_en` (text) - English advisory message
  - `assessed_at` (timestamptz) - Assessment timestamp
  
  ### `achievements`
  Tracks farmer achievements and badges
  - `id` (uuid, primary key)
  - `farmer_id` (uuid, foreign key) - References farmers
  - `badge_type` (text) - Type of achievement
  - `badge_name_en` (text) - English badge name
  - `badge_name_bn` (text) - Bangla badge name
  - `earned_at` (timestamptz) - When badge was earned
  
  ### `interventions`
  Records actions taken by farmers based on advisories
  - `id` (uuid, primary key)
  - `batch_id` (uuid, foreign key) - References crop_batches
  - `intervention_type` (text) - Type of action taken
  - `success` (boolean) - Whether intervention prevented loss
  - `notes` (text) - Additional details
  - `created_at` (timestamptz) - Intervention timestamp

  ## Security
  - RLS enabled on all tables
  - Farmers can only access their own data
  - Authenticated users required for all operations
*/

-- Create farmers table
CREATE TABLE IF NOT EXISTS farmers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email text UNIQUE NOT NULL,
  phone text NOT NULL,
  name text NOT NULL,
  preferred_language text DEFAULT 'bn' CHECK (preferred_language IN ('en', 'bn')),
  division text,
  district text,
  upazila text,
  achievement_points integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE farmers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Farmers can view own profile"
  ON farmers FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Farmers can update own profile"
  ON farmers FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Anyone can insert farmer profile"
  ON farmers FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- Create crop_batches table
CREATE TABLE IF NOT EXISTS crop_batches (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id uuid REFERENCES farmers(id) ON DELETE CASCADE NOT NULL,
  crop_type text NOT NULL DEFAULT 'paddy',
  estimated_weight numeric NOT NULL CHECK (estimated_weight > 0),
  harvest_date date NOT NULL,
  storage_location text NOT NULL,
  storage_type text NOT NULL CHECK (storage_type IN ('jute_bag', 'silo', 'open_area')),
  status text DEFAULT 'active' CHECK (status IN ('active', 'completed', 'lost')),
  actual_loss_kg numeric DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE crop_batches ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Farmers can view own batches"
  ON crop_batches FOR SELECT
  TO authenticated
  USING (farmer_id = auth.uid());

CREATE POLICY "Farmers can create own batches"
  ON crop_batches FOR INSERT
  TO authenticated
  WITH CHECK (farmer_id = auth.uid());

CREATE POLICY "Farmers can update own batches"
  ON crop_batches FOR UPDATE
  TO authenticated
  USING (farmer_id = auth.uid())
  WITH CHECK (farmer_id = auth.uid());

CREATE POLICY "Farmers can delete own batches"
  ON crop_batches FOR DELETE
  TO authenticated
  USING (farmer_id = auth.uid());

-- Create weather_cache table
CREATE TABLE IF NOT EXISTS weather_cache (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location_key text UNIQUE NOT NULL,
  forecast_data jsonb NOT NULL,
  fetched_at timestamptz DEFAULT now()
);

ALTER TABLE weather_cache ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view weather cache"
  ON weather_cache FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Anyone authenticated can insert weather cache"
  ON weather_cache FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Anyone authenticated can update weather cache"
  ON weather_cache FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Create risk_assessments table
CREATE TABLE IF NOT EXISTS risk_assessments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id uuid REFERENCES crop_batches(id) ON DELETE CASCADE NOT NULL,
  risk_level text NOT NULL CHECK (risk_level IN ('low', 'medium', 'high', 'critical')),
  etcl_hours integer NOT NULL,
  risk_factors jsonb NOT NULL DEFAULT '[]',
  advisory_bn text NOT NULL,
  advisory_en text NOT NULL,
  assessed_at timestamptz DEFAULT now()
);

ALTER TABLE risk_assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Farmers can view own risk assessments"
  ON risk_assessments FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM crop_batches
      WHERE crop_batches.id = risk_assessments.batch_id
      AND crop_batches.farmer_id = auth.uid()
    )
  );

CREATE POLICY "System can insert risk assessments"
  ON risk_assessments FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM crop_batches
      WHERE crop_batches.id = risk_assessments.batch_id
      AND crop_batches.farmer_id = auth.uid()
    )
  );

-- Create achievements table
CREATE TABLE IF NOT EXISTS achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  farmer_id uuid REFERENCES farmers(id) ON DELETE CASCADE NOT NULL,
  badge_type text NOT NULL,
  badge_name_en text NOT NULL,
  badge_name_bn text NOT NULL,
  earned_at timestamptz DEFAULT now()
);

ALTER TABLE achievements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Farmers can view own achievements"
  ON achievements FOR SELECT
  TO authenticated
  USING (farmer_id = auth.uid());

CREATE POLICY "System can insert achievements"
  ON achievements FOR INSERT
  TO authenticated
  WITH CHECK (farmer_id = auth.uid());

-- Create interventions table
CREATE TABLE IF NOT EXISTS interventions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  batch_id uuid REFERENCES crop_batches(id) ON DELETE CASCADE NOT NULL,
  intervention_type text NOT NULL,
  success boolean DEFAULT false,
  notes text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE interventions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Farmers can view own interventions"
  ON interventions FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM crop_batches
      WHERE crop_batches.id = interventions.batch_id
      AND crop_batches.farmer_id = auth.uid()
    )
  );

CREATE POLICY "Farmers can create interventions"
  ON interventions FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM crop_batches
      WHERE crop_batches.id = interventions.batch_id
      AND crop_batches.farmer_id = auth.uid()
    )
  );

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_crop_batches_farmer ON crop_batches(farmer_id);
CREATE INDEX IF NOT EXISTS idx_crop_batches_status ON crop_batches(status);
CREATE INDEX IF NOT EXISTS idx_risk_assessments_batch ON risk_assessments(batch_id);
CREATE INDEX IF NOT EXISTS idx_achievements_farmer ON achievements(farmer_id);
CREATE INDEX IF NOT EXISTS idx_interventions_batch ON interventions(batch_id);
CREATE INDEX IF NOT EXISTS idx_weather_cache_location ON weather_cache(location_key);
