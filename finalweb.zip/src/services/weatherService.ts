import { supabase } from '../lib/supabase';

export type WeatherData = {
  date: string;
  temp: number;
  humidity: number;
  rainChance: number;
  description: string;
};

const WEATHER_API_KEY = import.meta.env.VITE_WEATHER_API_KEY;
const CACHE_DURATION_HOURS = 6;

const DISTRICT_COORDS: Record<string, { lat: number; lon: number }> = {
  Dhaka: { lat: 23.8103, lon: 90.4125 },
  Chittagong: { lat: 22.3569, lon: 91.7832 },
  Rajshahi: { lat: 24.3745, lon: 88.6042 },
  Khulna: { lat: 22.8456, lon: 89.5403 },
  Barisal: { lat: 22.7010, lon: 90.3535 },
  Sylhet: { lat: 24.8949, lon: 91.8687 },
  Rangpur: { lat: 25.7439, lon: 89.2752 },
  Mymensingh: { lat: 24.7471, lon: 90.4203 },
};

export async function getWeatherForecast(
  division: string,
  district: string
): Promise<WeatherData[]> {
  const locationKey = `${division}-${district}`;

  try {
    const { data: cached } = await supabase
      .from('weather_cache')
      .select('*')
      .eq('location_key', locationKey)
      .maybeSingle();

    if (cached) {
      const cacheAge = Date.now() - new Date(cached.fetched_at).getTime();
      const cacheAgeHours = cacheAge / (1000 * 60 * 60);

      if (cacheAgeHours < CACHE_DURATION_HOURS) {
        return cached.forecast_data as WeatherData[];
      }
    }

    const coords = DISTRICT_COORDS[division] || DISTRICT_COORDS.Dhaka;

    if (!WEATHER_API_KEY) {
      return getMockWeatherData();
    }

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/forecast?lat=${coords.lat}&lon=${coords.lon}&units=metric&appid=${WEATHER_API_KEY}`
    );

    if (!response.ok) {
      return getMockWeatherData();
    }

    const data = await response.json();
    const forecast: WeatherData[] = [];
    const seenDates = new Set<string>();

    for (const item of data.list) {
      const date = new Date(item.dt * 1000).toISOString().split('T')[0];

      if (!seenDates.has(date) && forecast.length < 5) {
        seenDates.add(date);
        forecast.push({
          date,
          temp: Math.round(item.main.temp),
          humidity: item.main.humidity,
          rainChance: item.pop * 100,
          description: item.weather[0].description,
        });
      }
    }

    await supabase.from('weather_cache').upsert({
      location_key: locationKey,
      forecast_data: forecast,
      fetched_at: new Date().toISOString(),
    });

    return forecast;
  } catch (error) {
    console.error('Weather fetch error:', error);
    return getMockWeatherData();
  }
}

function getMockWeatherData(): WeatherData[] {
  const today = new Date();
  return Array.from({ length: 5 }, (_, i) => {
    const date = new Date(today);
    date.setDate(date.getDate() + i);

    return {
      date: date.toISOString().split('T')[0],
      temp: Math.round(28 + Math.random() * 8),
      humidity: Math.round(65 + Math.random() * 25),
      rainChance: Math.round(Math.random() * 80),
      description: 'partly cloudy',
    };
  });
}

export function generateBanglaAdvisory(
  weather: WeatherData[],
  storageType: string
): string {
  const highRainDays = weather.filter((w) => w.rainChance > 60).length;
  const highHumidity = weather.some((w) => w.humidity > 80);
  const highTemp = weather.some((w) => w.temp > 35);

  if (highRainDays >= 3) {
    return `আগামী ${highRainDays} দিন ${Math.round(weather[0].rainChance)}% বৃষ্টির সম্ভাবনা → আজই ধান কাটুন অথবা ঢেকে রাখুন। ${storageType === 'open_area' ? 'খোলা জায়গায় রাখবেন না!' : ''}`;
  }

  if (highHumidity && storageType === 'jute_bag') {
    return `আর্দ্রতা ${weather[0].humidity}% → পাটের বস্তায় ছত্রাক হতে পারে। বস্তাগুলি মাঝে মাঝে নাড়ান এবং বায়ু চলাচল নিশ্চিত করুন।`;
  }

  if (highTemp) {
    return `তাপমাত্রা ${weather[0].temp}°C উঠবে → দুপুরের দিকে ছায়া দিন এবং বায়ু চলাচল বাড়ান। রাতে ঠান্ডা করার চেষ্টা করুন।`;
  }

  return `আবহাওয়া অনুকূল। নিয়মিত ফসল পরীক্ষা করুন এবং পোকামাকড় এর জন্য লক্ষ্য রাখুন।`;
}

export function calculateETCL(
  harvestDate: string,
  storageType: string,
  weather: WeatherData[]
): { hours: number; riskLevel: 'low' | 'medium' | 'high' | 'critical' } {
  const daysSinceHarvest = Math.floor(
    (Date.now() - new Date(harvestDate).getTime()) / (1000 * 60 * 60 * 24)
  );

  const avgHumidity = weather.reduce((sum, w) => sum + w.humidity, 0) / weather.length;
  const avgTemp = weather.reduce((sum, w) => sum + w.temp, 0) / weather.length;
  const highRainDays = weather.filter((w) => w.rainChance > 60).length;

  let baseHours = 720;

  if (storageType === 'silo') {
    baseHours = 1440;
  } else if (storageType === 'open_area') {
    baseHours = 360;
  }

  let reductionFactor = 1;

  if (avgHumidity > 80) reductionFactor -= 0.3;
  if (avgTemp > 35) reductionFactor -= 0.2;
  if (highRainDays >= 2) reductionFactor -= 0.25;

  const remainingHours = Math.max(
    24,
    Math.floor(baseHours * reductionFactor - daysSinceHarvest * 24)
  );

  let riskLevel: 'low' | 'medium' | 'high' | 'critical' = 'low';
  if (remainingHours < 48) riskLevel = 'critical';
  else if (remainingHours < 120) riskLevel = 'high';
  else if (remainingHours < 240) riskLevel = 'medium';

  return { hours: remainingHours, riskLevel };
}
