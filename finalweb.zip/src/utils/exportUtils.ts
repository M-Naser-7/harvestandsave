import { CropBatch } from '../lib/supabase';

export function exportToCSV(batches: CropBatch[], fileName: string) {
  const headers = [
    'ID',
    'Crop Type',
    'Weight (kg)',
    'Harvest Date',
    'Storage Location',
    'Storage Type',
    'Status',
    'Actual Loss (kg)',
    'Created At',
  ];

  const rows = batches.map((batch) => [
    batch.id,
    batch.crop_type,
    batch.estimated_weight,
    batch.harvest_date,
    batch.storage_location,
    batch.storage_type,
    batch.status,
    batch.actual_loss_kg,
    batch.created_at,
  ]);

  const csvContent = [
    headers.join(','),
    ...rows.map((row) => row.map((cell) => `"${cell}"`).join(',')),
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', fileName);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

export function syncOfflineData() {
  const keys = Object.keys(localStorage);
  const batchKeys = keys.filter((key) => key.startsWith('batch_'));

  const offlineBatches = batchKeys.map((key) => {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : null;
  }).filter(Boolean);

  return offlineBatches;
}

export function clearOfflineData() {
  const keys = Object.keys(localStorage);
  const batchKeys = keys.filter((key) => key.startsWith('batch_'));
  batchKeys.forEach((key) => localStorage.removeItem(key));
}
