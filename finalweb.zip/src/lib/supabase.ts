import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Farmer = {
  id: string;
  email: string;
  phone: string;
  name: string;
  preferred_language: 'en' | 'bn';
  division?: string;
  district?: string;
  upazila?: string;
  achievement_points: number;
  created_at: string;
};

export type CropBatch = {
  id: string;
  farmer_id: string;
  crop_type: string;
  estimated_weight: number;
  harvest_date: string;
  storage_location: string;
  storage_type: 'jute_bag' | 'silo' | 'open_area';
  status: 'active' | 'completed' | 'lost';
  actual_loss_kg: number;
  created_at: string;
};

export type RiskAssessment = {
  id: string;
  batch_id: string;
  risk_level: 'low' | 'medium' | 'high' | 'critical';
  etcl_hours: number;
  risk_factors: Array<{
    factor: string;
    severity: number;
  }>;
  advisory_bn: string;
  advisory_en: string;
  assessed_at: string;
};

export type Achievement = {
  id: string;
  farmer_id: string;
  badge_type: string;
  badge_name_en: string;
  badge_name_bn: string;
  earned_at: string;
};
