import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase, Farmer } from '../lib/supabase';
import { User } from '@supabase/supabase-js';

type AuthContextType = {
  user: User | null;
  farmer: Farmer | null;
  loading: boolean;
  signUp: (email: string, password: string, farmerData: Partial<Farmer>) => Promise<void>;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
  updateFarmerProfile: (updates: Partial<Farmer>) => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [farmer, setFarmer] = useState<Farmer | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      if (session?.user) {
        loadFarmerProfile(session.user.id);
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      (async () => {
        setUser(session?.user ?? null);
        if (session?.user) {
          await loadFarmerProfile(session.user.id);
        } else {
          setFarmer(null);
          setLoading(false);
        }
      })();
    });

    return () => subscription.unsubscribe();
  }, []);

  async function loadFarmerProfile(userId: string) {
    try {
      const { data, error } = await supabase
        .from('farmers')
        .select('*')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;
      setFarmer(data);
    } catch (error) {
      console.error('Error loading farmer profile:', error);
    } finally {
      setLoading(false);
    }
  }

  async function signUp(email: string, password: string, farmerData: Partial<Farmer>) {
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
    });

    if (error) throw error;
    if (!data.user) throw new Error('User creation failed');

    const { error: profileError } = await supabase
      .from('farmers')
      .insert([{
        id: data.user.id,
        email,
        ...farmerData,
      }]);

    if (profileError) throw profileError;

    const { error: achievementError } = await supabase
      .from('achievements')
      .insert([{
        farmer_id: data.user.id,
        badge_type: 'first_registration',
        badge_name_en: 'First Harvest Logged',
        badge_name_bn: 'প্রথম ফসল নিবন্ধিত',
      }]);

    if (achievementError) console.error('Achievement error:', achievementError);
  }

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) throw error;
  }

  async function signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }

  async function updateFarmerProfile(updates: Partial<Farmer>) {
    if (!user) throw new Error('No user logged in');

    const { error } = await supabase
      .from('farmers')
      .update(updates)
      .eq('id', user.id);

    if (error) throw error;
    await loadFarmerProfile(user.id);
  }

  return (
    <AuthContext.Provider value={{
      user,
      farmer,
      loading,
      signUp,
      signIn,
      signOut,
      updateFarmerProfile,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
