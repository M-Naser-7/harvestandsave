import { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { useAuth } from './AuthContext';

type Language = 'en' | 'bn';

type LanguageContextType = {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations: Record<string, Record<Language, string>> = {
  app_title: {
    en: 'HarvestGuard',
    bn: 'হারভেস্টগার্ড',
  },
  problem_title: {
    en: 'The Crisis of Food Loss in Bangladesh',
    bn: 'বাংলাদেশে খাদ্য অপচয়ের সংকট',
  },
  problem_desc: {
    en: 'Every year, Bangladesh loses 4.5 million metric tonnes of food grains worth $1.5 billion due to poor storage, handling, and transportation.',
    bn: 'প্রতি বছর বাংলাদেশে ৪৫ লক্ষ মেট্রিক টন খাদ্যশস্য নষ্ট হয় যার মূল্য ১৫০ কোটি ডলার, খারাপ সংরক্ষণ এবং পরিবহনের কারণে।',
  },
  solution_title: {
    en: 'Our Solution: Smart Protection for Your Harvest',
    bn: 'আমাদের সমাধান: আপনার ফসলের স্মার্ট সুরক্ষা',
  },
  get_started: {
    en: 'Get Started',
    bn: 'শুরু করুন',
  },
  sign_in: {
    en: 'Sign In',
    bn: 'সাইন ইন',
  },
  sign_up: {
    en: 'Sign Up',
    bn: 'নিবন্ধন করুন',
  },
  email: {
    en: 'Email',
    bn: 'ইমেইল',
  },
  password: {
    en: 'Password',
    bn: 'পাসওয়ার্ড',
  },
  name: {
    en: 'Full Name',
    bn: 'পূর্ণ নাম',
  },
  phone: {
    en: 'Phone Number',
    bn: 'ফোন নম্বর',
  },
  division: {
    en: 'Division',
    bn: 'বিভাগ',
  },
  district: {
    en: 'District',
    bn: 'জেলা',
  },
  upazila: {
    en: 'Upazila',
    bn: 'উপজেলা',
  },
  dashboard: {
    en: 'Dashboard',
    bn: 'ড্যাশবোর্ড',
  },
  my_crops: {
    en: 'My Crops',
    bn: 'আমার ফসল',
  },
  add_crop: {
    en: 'Add New Crop Batch',
    bn: 'নতুন ফসল যোগ করুন',
  },
  crop_type: {
    en: 'Crop Type',
    bn: 'ফসলের ধরন',
  },
  paddy: {
    en: 'Paddy/Rice',
    bn: 'ধান/চাল',
  },
  weight: {
    en: 'Estimated Weight (kg)',
    bn: 'আনুমানিক ওজন (কেজি)',
  },
  harvest_date: {
    en: 'Harvest Date',
    bn: 'ফসল কাটার তারিখ',
  },
  storage_location: {
    en: 'Storage Location',
    bn: 'সংরক্ষণের স্থান',
  },
  storage_type: {
    en: 'Storage Type',
    bn: 'সংরক্ষণের ধরন',
  },
  jute_bag: {
    en: 'Jute Bag Stack',
    bn: 'পাটের বস্তায়',
  },
  silo: {
    en: 'Silo',
    bn: 'সাইলো',
  },
  open_area: {
    en: 'Open Area',
    bn: 'খোলা জায়গা',
  },
  weather: {
    en: 'Weather Forecast',
    bn: 'আবহাওয়ার পূর্বাভাস',
  },
  temperature: {
    en: 'Temperature',
    bn: 'তাপমাত্রা',
  },
  humidity: {
    en: 'Humidity',
    bn: 'আর্দ্রতা',
  },
  rain_chance: {
    en: 'Rain Chance',
    bn: 'বৃষ্টির সম্ভাবনা',
  },
  risk_level: {
    en: 'Risk Level',
    bn: 'ঝুঁকির মাত্রা',
  },
  low: {
    en: 'Low',
    bn: 'কম',
  },
  medium: {
    en: 'Medium',
    bn: 'মাঝারি',
  },
  high: {
    en: 'High',
    bn: 'উচ্চ',
  },
  critical: {
    en: 'Critical',
    bn: 'সংকটজনক',
  },
  achievements: {
    en: 'Achievements',
    bn: 'অর্জন',
  },
  profile: {
    en: 'Profile',
    bn: 'প্রোফাইল',
  },
  logout: {
    en: 'Logout',
    bn: 'লগ আউট',
  },
  active_batches: {
    en: 'Active Batches',
    bn: 'সক্রিয় ফসল',
  },
  save: {
    en: 'Save',
    bn: 'সংরক্ষণ করুন',
  },
  cancel: {
    en: 'Cancel',
    bn: 'বাতিল',
  },
  scanner: {
    en: 'Crop Scanner',
    bn: 'ফসল স্ক্যানার',
  },
  upload_photo: {
    en: 'Upload Photo',
    bn: 'ছবি আপলোড করুন',
  },
  scan_result: {
    en: 'Scan Result',
    bn: 'স্ক্যান ফলাফল',
  },
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const { farmer } = useAuth();
  const [language, setLanguageState] = useState<Language>('bn');

  useEffect(() => {
    if (farmer?.preferred_language) {
      setLanguageState(farmer.preferred_language);
    }
  }, [farmer]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    if (farmer) {
      const { updateFarmerProfile } = useAuth();
      updateFarmerProfile({ preferred_language: lang });
    }
  };

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
