import { useState } from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { Wheat } from 'lucide-react';

type AddCropFormProps = {
  onSuccess: () => void;
};

export function AddCropForm({ onSuccess }: AddCropFormProps) {
  const { t, language } = useLanguage();
  const { farmer } = useAuth();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    crop_type: 'paddy',
    estimated_weight: '',
    harvest_date: new Date().toISOString().split('T')[0],
    storage_location: '',
    storage_type: 'jute_bag' as 'jute_bag' | 'silo' | 'open_area',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!farmer) return;

    setError('');
    setLoading(true);

    try {
      const { data: batch, error: batchError } = await supabase
        .from('crop_batches')
        .insert([
          {
            farmer_id: farmer.id,
            ...formData,
            estimated_weight: parseFloat(formData.estimated_weight),
            storage_location: formData.storage_location || `${farmer.division}, ${farmer.district}`,
          },
        ])
        .select()
        .single();

      if (batchError) throw batchError;

      const batchCount = await supabase
        .from('crop_batches')
        .select('id', { count: 'exact', head: true })
        .eq('farmer_id', farmer.id);

      if (batchCount.count === 1) {
        await supabase.from('achievements').insert([
          {
            farmer_id: farmer.id,
            badge_type: 'first_batch',
            badge_name_en: 'First Harvest Logged',
            badge_name_bn: 'প্রথম ফসল নিবন্ধিত',
          },
        ]);
      }

      const offlineKey = `batch_${batch.id}`;
      localStorage.setItem(offlineKey, JSON.stringify(batch));

      onSuccess();
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError('An error occurred');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-xl shadow-md p-8">
        <div className="flex items-center space-x-3 mb-6">
          <Wheat className="w-8 h-8 text-green-600" />
          <h2 className="text-2xl font-bold text-gray-900">{t('add_crop')}</h2>
        </div>

        {error && (
          <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('crop_type')}
            </label>
            <select
              value={formData.crop_type}
              onChange={(e) => setFormData({ ...formData, crop_type: e.target.value })}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-200 outline-none transition text-lg"
            >
              <option value="paddy">{t('paddy')}</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('weight')}
            </label>
            <input
              type="number"
              required
              min="1"
              step="0.1"
              value={formData.estimated_weight}
              onChange={(e) => setFormData({ ...formData, estimated_weight: e.target.value })}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-200 outline-none transition text-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('harvest_date')}
            </label>
            <input
              type="date"
              required
              value={formData.harvest_date}
              onChange={(e) => setFormData({ ...formData, harvest_date: e.target.value })}
              max={new Date().toISOString().split('T')[0]}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-200 outline-none transition text-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('storage_location')}
            </label>
            <input
              type="text"
              value={formData.storage_location}
              onChange={(e) => setFormData({ ...formData, storage_location: e.target.value })}
              placeholder={`${farmer?.division}, ${farmer?.district}`}
              className="w-full px-4 py-3 border-2 border-gray-300 rounded-lg focus:border-green-500 focus:ring-2 focus:ring-green-200 outline-none transition text-lg"
            />
          </div>

          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-2">
              {t('storage_type')}
            </label>
            <div className="grid grid-cols-3 gap-4">
              {(['jute_bag', 'silo', 'open_area'] as const).map((type) => (
                <button
                  key={type}
                  type="button"
                  onClick={() => setFormData({ ...formData, storage_type: type })}
                  className={`p-4 rounded-lg border-2 transition-all ${
                    formData.storage_type === type
                      ? 'border-green-500 bg-green-50 text-green-700 font-semibold'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  {t(type)}
                </button>
              ))}
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-green-600 hover:bg-green-700 text-white text-lg font-bold rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading
              ? (language === 'en' ? 'Saving...' : 'সংরক্ষণ হচ্ছে...')
              : t('save')}
          </button>
        </form>
      </div>
    </div>
  );
}
