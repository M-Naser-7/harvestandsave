import { useState, useEffect } from 'react';
import { Wheat, Award, Plus, AlertCircle, TrendingUp } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { supabase, CropBatch, Achievement } from '../lib/supabase';
import { AddCropForm } from './AddCropForm';
import { CropBatchCard } from './CropBatchCard';
import { WeatherWidget } from './WeatherWidget';
import { ProfileSection } from './ProfileSection';
import { CropScanner } from './CropScanner';

export function Dashboard() {
  const { t, language } = useLanguage();
  const { farmer, signOut } = useAuth();
  const [view, setView] = useState<'dashboard' | 'crops' | 'add-crop' | 'profile' | 'scanner'>('dashboard');
  const [batches, setBatches] = useState<CropBatch[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (farmer) {
      loadData();
    }
  }, [farmer]);

  async function loadData() {
    if (!farmer) return;

    try {
      const [batchesRes, achievementsRes] = await Promise.all([
        supabase
          .from('crop_batches')
          .select('*')
          .eq('farmer_id', farmer.id)
          .order('created_at', { ascending: false }),
        supabase
          .from('achievements')
          .select('*')
          .eq('farmer_id', farmer.id)
          .order('earned_at', { ascending: false }),
      ]);

      if (batchesRes.data) setBatches(batchesRes.data);
      if (achievementsRes.data) setAchievements(achievementsRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  }

  const activeBatches = batches.filter((b) => b.status === 'active');
  const totalWeight = activeBatches.reduce((sum, b) => sum + b.estimated_weight, 0);
  const totalLossPrevented = batches.reduce((sum, b) => {
    if (b.status === 'completed') {
      return sum + (b.estimated_weight - b.actual_loss_kg);
    }
    return sum;
  }, 0);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <div className="text-2xl text-gray-600">
          {language === 'en' ? 'Loading...' : 'লোড হচ্ছে...'}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-green-800">
              {language === 'en' ? 'HarvestGuard' : 'হারভেস্টগার্ড'}
            </h1>
            <div className="flex items-center space-x-4">
              <span className="text-gray-700 font-semibold">{farmer?.name}</span>
              <button
                onClick={() => signOut()}
                className="px-4 py-2 bg-red-500 hover:bg-red-600 text-white rounded-lg transition-colors"
              >
                {t('logout')}
              </button>
            </div>
          </div>
        </div>
      </header>

      <nav className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex space-x-2 overflow-x-auto">
            {[
              { key: 'dashboard', icon: TrendingUp },
              { key: 'crops', icon: Wheat },
              { key: 'add-crop', icon: Plus },
              { key: 'scanner', icon: AlertCircle },
              { key: 'profile', icon: Award },
            ].map(({ key, icon: Icon }) => (
              <button
                key={key}
                onClick={() => setView(key as typeof view)}
                className={`flex items-center space-x-2 px-6 py-4 font-semibold transition-colors whitespace-nowrap ${
                  view === key
                    ? 'text-green-600 border-b-2 border-green-600'
                    : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span>{t(key.replace('-', '_'))}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {view === 'dashboard' && (
          <div className="space-y-6">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-700">
                    {t('active_batches')}
                  </h3>
                  <Wheat className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-4xl font-bold text-gray-900">{activeBatches.length}</p>
              </div>

              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-700">
                    {language === 'en' ? 'Total Weight' : 'মোট ওজন'}
                  </h3>
                  <TrendingUp className="w-8 h-8 text-blue-600" />
                </div>
                <p className="text-4xl font-bold text-gray-900">
                  {Math.round(totalWeight)}
                  <span className="text-xl text-gray-600 ml-2">
                    {language === 'en' ? 'kg' : 'কেজি'}
                  </span>
                </p>
              </div>

              <div className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-lg font-semibold text-gray-700">
                    {language === 'en' ? 'Saved' : 'সংরক্ষিত'}
                  </h3>
                  <Award className="w-8 h-8 text-yellow-600" />
                </div>
                <p className="text-4xl font-bold text-gray-900">
                  {Math.round(totalLossPrevented)}
                  <span className="text-xl text-gray-600 ml-2">
                    {language === 'en' ? 'kg' : 'কেজি'}
                  </span>
                </p>
              </div>
            </div>

            {farmer && (
              <WeatherWidget
                division={farmer.division || 'Dhaka'}
                district={farmer.district || 'Dhaka'}
              />
            )}

            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                {language === 'en' ? 'Recent Batches' : 'সাম্প্রতিক ফসল'}
              </h2>
              {activeBatches.length === 0 ? (
                <div className="bg-white rounded-xl shadow-md p-12 text-center">
                  <Wheat className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 text-lg mb-6">
                    {language === 'en'
                      ? 'No active batches. Add your first harvest!'
                      : 'কোন সক্রিয় ফসল নেই। আপনার প্রথম ফসল যোগ করুন!'}
                  </p>
                  <button
                    onClick={() => setView('add-crop')}
                    className="px-8 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold"
                  >
                    {t('add_crop')}
                  </button>
                </div>
              ) : (
                <div className="grid md:grid-cols-2 gap-6">
                  {activeBatches.slice(0, 4).map((batch) => (
                    <CropBatchCard key={batch.id} batch={batch} onUpdate={loadData} />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {view === 'crops' && (
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">{t('my_crops')}</h2>
            {batches.length === 0 ? (
              <div className="bg-white rounded-xl shadow-md p-12 text-center">
                <Wheat className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600 text-lg">
                  {language === 'en' ? 'No crops registered yet' : 'এখনো কোন ফসল নিবন্ধিত নেই'}
                </p>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 gap-6">
                {batches.map((batch) => (
                  <CropBatchCard key={batch.id} batch={batch} onUpdate={loadData} />
                ))}
              </div>
            )}
          </div>
        )}

        {view === 'add-crop' && <AddCropForm onSuccess={() => { loadData(); setView('crops'); }} />}

        {view === 'scanner' && <CropScanner />}

        {view === 'profile' && <ProfileSection achievements={achievements} />}
      </main>
    </div>
  );
}
