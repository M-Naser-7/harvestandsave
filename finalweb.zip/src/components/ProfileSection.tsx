import { Award, User, Download, FileText } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { Achievement } from '../lib/supabase';
import { supabase } from '../lib/supabase';
import { exportToCSV } from '../utils/exportUtils';

type ProfileSectionProps = {
  achievements: Achievement[];
};

export function ProfileSection({ achievements }: ProfileSectionProps) {
  const { t, language } = useLanguage();
  const { farmer } = useAuth();

  const exportJSON = async () => {
    if (!farmer) return;

    try {
      const { data: batches } = await supabase
        .from('crop_batches')
        .select('*')
        .eq('farmer_id', farmer.id);

      const { data: risks } = await supabase
        .from('risk_assessments')
        .select('*')
        .eq('batch_id', { in: batches?.map(b => b.id) || [] });

      const exportData = {
        farmer: {
          name: farmer.name,
          phone: farmer.phone,
          location: `${farmer.division}, ${farmer.district}, ${farmer.upazila}`,
          achievement_points: farmer.achievement_points,
        },
        batches: batches || [],
        achievements: achievements,
        risk_assessments: risks || [],
        exported_at: new Date().toISOString(),
      };

      const dataStr = JSON.stringify(exportData, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `harvestguard_${farmer.name}_${Date.now()}.json`;
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export error:', error);
    }
  };

  const exportCSVData = async () => {
    if (!farmer) return;

    try {
      const { data: batches } = await supabase
        .from('crop_batches')
        .select('*')
        .eq('farmer_id', farmer.id);

      if (batches) {
        exportToCSV(batches, `harvestguard_${farmer.name}_${Date.now()}.csv`);
      }
    } catch (error) {
      console.error('CSV export error:', error);
    }
  };

  const badgeColors = [
    'bg-yellow-100 text-yellow-800 border-yellow-300',
    'bg-blue-100 text-blue-800 border-blue-300',
    'bg-green-100 text-green-800 border-green-300',
    'bg-purple-100 text-purple-800 border-purple-300',
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-xl shadow-md p-8">
        <div className="flex items-center space-x-4 mb-6">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center">
            <User className="w-10 h-10 text-green-600" />
          </div>
          <div>
            <h2 className="text-3xl font-bold text-gray-900">{farmer?.name}</h2>
            <p className="text-gray-600">{farmer?.email}</p>
            <p className="text-gray-600">{farmer?.phone}</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4 mb-6">
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 mb-1">{language === 'en' ? 'Location' : 'অবস্থান'}</p>
            <p className="font-semibold text-gray-900">
              {farmer?.division}, {farmer?.district}, {farmer?.upazila}
            </p>
          </div>
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 mb-1">
              {language === 'en' ? 'Achievement Points' : 'অর্জন পয়েন্ট'}
            </p>
            <p className="font-semibold text-gray-900 text-2xl">{farmer?.achievement_points || 0}</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            onClick={exportJSON}
            className="flex items-center space-x-2 px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition-colors"
          >
            <Download className="w-5 h-5" />
            <span>{language === 'en' ? 'Export JSON' : 'JSON রপ্তানি'}</span>
          </button>
          <button
            onClick={exportCSVData}
            className="flex items-center space-x-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-semibold transition-colors"
          >
            <FileText className="w-5 h-5" />
            <span>{language === 'en' ? 'Export CSV' : 'CSV রপ্তানি'}</span>
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md p-8">
        <div className="flex items-center space-x-3 mb-6">
          <Award className="w-8 h-8 text-yellow-600" />
          <h3 className="text-2xl font-bold text-gray-900">{t('achievements')}</h3>
        </div>

        {achievements.length === 0 ? (
          <div className="text-center py-12">
            <Award className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">
              {language === 'en'
                ? 'No achievements yet. Start protecting your crops to earn badges!'
                : 'এখনো কোন অর্জন নেই। ব্যাজ পেতে আপনার ফসল রক্ষা শুরু করুন!'}
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {achievements.map((achievement, idx) => (
              <div
                key={achievement.id}
                className={`p-6 rounded-xl border-2 ${badgeColors[idx % badgeColors.length]}`}
              >
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center">
                    <Award className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-lg">
                      {language === 'en' ? achievement.badge_name_en : achievement.badge_name_bn}
                    </h4>
                    <p className="text-sm opacity-75">
                      {new Date(achievement.earned_at).toLocaleDateString(
                        language === 'bn' ? 'bn-BD' : 'en-US',
                        { year: 'numeric', month: 'long', day: 'numeric' }
                      )}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
