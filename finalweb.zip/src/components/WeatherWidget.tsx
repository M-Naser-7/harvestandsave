import { useState, useEffect } from 'react';
import { Cloud, Droplets, Thermometer } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { getWeatherForecast, WeatherData } from '../services/weatherService';

type WeatherWidgetProps = {
  division: string;
  district: string;
};

export function WeatherWidget({ division, district }: WeatherWidgetProps) {
  const { t, language } = useLanguage();
  const [weather, setWeather] = useState<WeatherData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadWeather();
  }, [division, district]);

  async function loadWeather() {
    try {
      const data = await getWeatherForecast(division, district);
      setWeather(data);
    } catch (error) {
      console.error('Weather error:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-md p-6">
        <p className="text-gray-600">{language === 'en' ? 'Loading weather...' : 'আবহাওয়া লোড হচ্ছে...'}</p>
      </div>
    );
  }

  const getBanglaNumber = (num: number): string => {
    const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().split('').map(d => banglaDigits[parseInt(d)] || d).join('');
  };

  const formatDate = (dateStr: string): string => {
    const date = new Date(dateStr);
    if (language === 'bn') {
      const options: Intl.DateTimeFormatOptions = { weekday: 'short', month: 'short', day: 'numeric' };
      return date.toLocaleDateString('bn-BD', options);
    }
    return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  return (
    <div className="bg-gradient-to-br from-blue-50 to-white rounded-xl shadow-md p-6">
      <div className="flex items-center space-x-3 mb-6">
        <Cloud className="w-8 h-8 text-blue-600" />
        <h2 className="text-2xl font-bold text-gray-900">{t('weather')}</h2>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        {weather.map((day, idx) => (
          <div
            key={idx}
            className="bg-white rounded-lg p-4 border-2 border-blue-100 hover:border-blue-300 transition-colors"
          >
            <p className="text-sm font-semibold text-gray-600 mb-3 text-center">
              {formatDate(day.date)}
            </p>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Thermometer className="w-4 h-4 text-orange-500" />
                <span className="font-bold text-gray-900">
                  {language === 'bn' ? getBanglaNumber(day.temp) : day.temp}°C
                </span>
              </div>

              <div className="flex items-center justify-between">
                <Droplets className="w-4 h-4 text-blue-500" />
                <span className="text-sm text-gray-700">
                  {language === 'bn' ? getBanglaNumber(day.humidity) : day.humidity}%
                </span>
              </div>

              <div className="flex items-center justify-between">
                <Cloud className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-700">
                  {language === 'bn' ? getBanglaNumber(Math.round(day.rainChance)) : Math.round(day.rainChance)}%
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {weather[0] && (
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
          <p className="text-sm font-semibold text-blue-900 mb-1">
            {language === 'en' ? 'Today\'s Forecast' : 'আজকের পূর্বাভাস'}
          </p>
          <p className="text-blue-800">
            {language === 'en'
              ? `${weather[0].temp}°C, ${weather[0].humidity}% humidity, ${Math.round(weather[0].rainChance)}% chance of rain`
              : `${getBanglaNumber(weather[0].temp)}°C তাপমাত্রা, ${getBanglaNumber(weather[0].humidity)}% আর্দ্রতা, ${getBanglaNumber(Math.round(weather[0].rainChance))}% বৃষ্টির সম্ভাবনা`}
          </p>
        </div>
      )}
    </div>
  );
}
