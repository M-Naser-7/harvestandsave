import { useState, useEffect } from 'react';
import { AlertTriangle, CheckCircle, Wheat, MapPin, Calendar } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { CropBatch, RiskAssessment } from '../lib/supabase';
import { supabase } from '../lib/supabase';
import { getWeatherForecast, calculateETCL, generateBanglaAdvisory } from '../services/weatherService';

type CropBatchCardProps = {
  batch: CropBatch;
  onUpdate: () => void;
};

export function CropBatchCard({ batch }: CropBatchCardProps) {
  const { t, language } = useLanguage();
  const [risk, setRisk] = useState<RiskAssessment | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRiskAssessment();
  }, [batch.id]);

  async function loadRiskAssessment() {
    try {
      const { data: existing } = await supabase
        .from('risk_assessments')
        .select('*')
        .eq('batch_id', batch.id)
        .order('assessed_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (existing) {
        const assessmentAge = Date.now() - new Date(existing.assessed_at).getTime();
        const ageHours = assessmentAge / (1000 * 60 * 60);

        if (ageHours < 12) {
          setRisk(existing);
          setLoading(false);
          return;
        }
      }

      const [division] = batch.storage_location.split(',');
      const weather = await getWeatherForecast(division.trim(), '');

      const etcl = calculateETCL(batch.harvest_date, batch.storage_type, weather);
      const advisoryBn = generateBanglaAdvisory(weather, batch.storage_type);

      const newAssessment = {
        batch_id: batch.id,
        risk_level: etcl.riskLevel,
        etcl_hours: etcl.hours,
        risk_factors: [
          { factor: 'storage_type', severity: batch.storage_type === 'open_area' ? 3 : 1 },
          { factor: 'weather', severity: weather[0].rainChance > 60 ? 3 : 1 },
        ],
        advisory_bn: advisoryBn,
        advisory_en: `ETCL: ${Math.floor(etcl.hours / 24)} days. Monitor storage conditions closely.`,
      };

      const { data, error } = await supabase
        .from('risk_assessments')
        .insert([newAssessment])
        .select()
        .single();

      if (error) throw error;
      setRisk(data);
    } catch (error) {
      console.error('Error loading risk:', error);
    } finally {
      setLoading(false);
    }
  }

  const riskColors = {
    low: 'bg-green-100 text-green-800 border-green-300',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
    high: 'bg-orange-100 text-orange-800 border-orange-300',
    critical: 'bg-red-100 text-red-800 border-red-300',
  };

  const riskIcons = {
    low: CheckCircle,
    medium: AlertTriangle,
    high: AlertTriangle,
    critical: AlertTriangle,
  };

  const RiskIcon = risk ? riskIcons[risk.risk_level] : AlertTriangle;

  return (
    <div className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-lg transition-shadow">
      <div className={`p-4 ${risk ? riskColors[risk.risk_level] : 'bg-gray-100'} border-b-2`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <RiskIcon className="w-5 h-5" />
            <span className="font-bold text-sm uppercase">
              {loading ? (language === 'en' ? 'Loading...' : 'লোড হচ্ছে...') : t(risk?.risk_level || 'low')}
            </span>
          </div>
          {risk && (
            <span className="text-sm font-semibold">
              {language === 'en'
                ? `${Math.floor(risk.etcl_hours / 24)}d ${risk.etcl_hours % 24}h`
                : `${Math.floor(risk.etcl_hours / 24)}দিন`}
            </span>
          )}
        </div>
      </div>

      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3">
            <Wheat className="w-8 h-8 text-green-600" />
            <div>
              <h3 className="text-xl font-bold text-gray-900">{t(batch.crop_type)}</h3>
              <p className="text-gray-600">
                {batch.estimated_weight} {language === 'en' ? 'kg' : 'কেজি'}
              </p>
            </div>
          </div>
          <span
            className={`px-3 py-1 rounded-full text-sm font-semibold ${
              batch.status === 'active'
                ? 'bg-blue-100 text-blue-800'
                : batch.status === 'completed'
                ? 'bg-green-100 text-green-800'
                : 'bg-red-100 text-red-800'
            }`}
          >
            {t(batch.status)}
          </span>
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex items-center space-x-2 text-gray-600">
            <MapPin className="w-4 h-4" />
            <span className="text-sm">{batch.storage_location}</span>
          </div>
          <div className="flex items-center space-x-2 text-gray-600">
            <Calendar className="w-4 h-4" />
            <span className="text-sm">
              {language === 'en' ? 'Harvested' : 'কাটা হয়েছে'}: {new Date(batch.harvest_date).toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US')}
            </span>
          </div>
          <div className="text-gray-600 text-sm">
            {language === 'en' ? 'Storage' : 'সংরক্ষণ'}: {t(batch.storage_type)}
          </div>
        </div>

        {risk && (
          <div className="mt-4 p-4 bg-gray-50 rounded-lg border-2 border-gray-200">
            <h4 className="font-semibold text-gray-900 mb-2">
              {language === 'en' ? 'Advisory' : 'পরামর্শ'}
            </h4>
            <p className="text-gray-700 leading-relaxed">
              {language === 'en' ? risk.advisory_en : risk.advisory_bn}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
