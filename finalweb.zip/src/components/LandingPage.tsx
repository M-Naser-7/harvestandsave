import { useState } from 'react';
import { Wheat, TrendingDown, AlertTriangle, Shield, ArrowRight, Globe } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

type LandingPageProps = {
  onGetStarted: () => void;
};

export function LandingPage({ onGetStarted }: LandingPageProps) {
  const { language, setLanguage, t } = useLanguage();
  const [step, setStep] = useState(0);

  const problems = [
    {
      icon: TrendingDown,
      titleEn: '4.5 Million Tonnes Lost',
      titleBn: '৪৫ লক্ষ মেট্রিক টন নষ্ট',
      descEn: 'Every year, food grains worth $1.5 billion are wasted',
      descBn: 'প্রতি বছর ১৫০ কোটি ডলার মূল্যের খাদ্যশস্য নষ্ট হয়',
    },
    {
      icon: AlertTriangle,
      titleEn: 'Poor Storage Systems',
      titleBn: 'দুর্বল সংরক্ষণ ব্যবস্থা',
      descEn: 'Inadequate facilities lead to mold, pests, and spoilage',
      descBn: 'অপর্যাপ্ত সুবিধার কারণে পচন এবং পোকার আক্রমণ',
    },
    {
      icon: Wheat,
      titleEn: '12-32% Food Loss',
      titleBn: '১২-৩২% খাদ্য ক্ষতি',
      descEn: 'Rice, pulses, vegetables, and dairy lost during production',
      descBn: 'চাল, ডাল, সবজি এবং দুধজাত পণ্য উৎপাদনে নষ্ট',
    },
  ];

  const solutions = [
    {
      titleEn: 'Real-Time Monitoring',
      titleBn: 'রিয়েল-টাইম পর্যবেক্ষণ',
      descEn: 'Track weather, humidity, and temperature risks instantly',
      descBn: 'আবহাওয়া, আর্দ্রতা এবং তাপমাত্রার ঝুঁকি তাৎক্ষণিক ট্র্যাক করুন',
    },
    {
      titleEn: 'Early Warning System',
      titleBn: 'প্রাথমিক সতর্কতা ব্যবস্থা',
      descEn: 'Get alerts before crops reach critical loss point',
      descBn: 'ফসল নষ্ট হওয়ার আগেই সতর্কবার্তা পান',
    },
    {
      titleEn: 'Smart Advisories',
      titleBn: 'স্মার্ট পরামর্শ',
      descEn: 'Receive actionable advice in Bangla to save your harvest',
      descBn: 'আপনার ফসল বাঁচাতে বাংলায় কার্যকর পরামর্শ পান',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50">
      <header className="fixed top-0 left-0 right-0 bg-white/80 backdrop-blur-sm shadow-sm z-50">
        <div className="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Shield className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-800">
              {language === 'en' ? 'HarvestGuard' : 'হারভেস্টগার্ড'}
            </h1>
          </div>
          <button
            onClick={() => setLanguage(language === 'en' ? 'bn' : 'en')}
            className="flex items-center space-x-2 px-4 py-2 rounded-lg bg-green-100 text-green-800 hover:bg-green-200 transition-colors"
          >
            <Globe className="w-5 h-5" />
            <span className="font-semibold">{language === 'en' ? 'বাংলা' : 'English'}</span>
          </button>
        </div>
      </header>

      <main className="pt-24 pb-12">
        <section className="max-w-7xl mx-auto px-4 py-16">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6">
              {t('problem_title')}
            </h2>
            <p className="text-xl md:text-2xl text-gray-700 max-w-4xl mx-auto leading-relaxed">
              {t('problem_desc')}
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-20">
            {problems.map((problem, idx) => {
              const Icon = problem.icon;
              return (
                <div
                  key={idx}
                  className="bg-white rounded-2xl shadow-lg p-8 hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2"
                  style={{ animationDelay: `${idx * 150}ms` }}
                >
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-6">
                    <Icon className="w-8 h-8 text-red-600" />
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 mb-4">
                    {language === 'en' ? problem.titleEn : problem.titleBn}
                  </h3>
                  <p className="text-lg text-gray-600 leading-relaxed">
                    {language === 'en' ? problem.descEn : problem.descBn}
                  </p>
                </div>
              );
            })}
          </div>

          <div className="my-20">
            <div className="max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-green-600 to-green-500 rounded-3xl p-12 text-white text-center shadow-2xl">
                <h2 className="text-4xl md:text-5xl font-bold mb-6">
                  {t('solution_title')}
                </h2>
                <p className="text-xl mb-8 opacity-90">
                  {language === 'en'
                    ? 'Use technology to protect your harvest and increase your income'
                    : 'প্রযুক্তি ব্যবহার করে আপনার ফসল রক্ষা করুন এবং আয় বৃদ্ধি করুন'}
                </p>

                <div className="flex justify-center space-x-4 mb-8">
                  {[0, 1, 2, 3].map((idx) => (
                    <div
                      key={idx}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        step === idx ? 'bg-white w-8' : 'bg-white/50'
                      }`}
                    />
                  ))}
                </div>

                <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 mb-8 min-h-48">
                  {step === 0 && (
                    <div className="animate-fade-in">
                      <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Wheat className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold mb-3">
                        {language === 'en' ? '1. Register Your Crop' : '১. আপনার ফসল নিবন্ধন করুন'}
                      </h3>
                      <p className="text-lg opacity-90">
                        {language === 'en'
                          ? 'Add details about your harvest, storage location, and type'
                          : 'আপনার ফসল, সংরক্ষণের স্থান এবং ধরন সম্পর্কে তথ্য যোগ করুন'}
                      </p>
                    </div>
                  )}
                  {step === 1 && (
                    <div className="animate-fade-in">
                      <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <AlertTriangle className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold mb-3">
                        {language === 'en' ? '2. Get Early Warnings' : '২. প্রাথমিক সতর্কতা পান'}
                      </h3>
                      <p className="text-lg opacity-90">
                        {language === 'en'
                          ? 'Receive alerts about weather risks and storage conditions'
                          : 'আবহাওয়ার ঝুঁকি এবং সংরক্ষণের অবস্থা সম্পর্কে সতর্কবার্তা পান'}
                      </p>
                    </div>
                  )}
                  {step === 2 && (
                    <div className="animate-fade-in">
                      <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Shield className="w-10 h-10 text-white" />
                      </div>
                      <h3 className="text-2xl font-bold mb-3">
                        {language === 'en' ? '3. Take Action' : '৩. ব্যবস্থা নিন'}
                      </h3>
                      <p className="text-lg opacity-90">
                        {language === 'en'
                          ? 'Follow simple Bangla instructions to protect your crops'
                          : 'আপনার ফসল রক্ষা করতে সহজ বাংলা নির্দেশনা অনুসরণ করুন'}
                      </p>
                    </div>
                  )}
                  {step === 3 && (
                    <div className="animate-fade-in">
                      <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <TrendingDown className="w-10 h-10 text-white transform rotate-180" />
                      </div>
                      <h3 className="text-2xl font-bold mb-3">
                        {language === 'en' ? '4. Save Your Harvest' : '৪. আপনার ফসল বাঁচান'}
                      </h3>
                      <p className="text-lg opacity-90">
                        {language === 'en'
                          ? 'Reduce losses and earn achievements as you protect your crops'
                          : 'ক্ষতি কমান এবং আপনার ফসল রক্ষা করার সাথে সাথে অর্জন অর্জন করুন'}
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex justify-center space-x-4">
                  <button
                    onClick={() => setStep((step - 1 + 4) % 4)}
                    className="px-6 py-3 bg-white/20 hover:bg-white/30 rounded-lg font-semibold transition-colors"
                  >
                    ←
                  </button>
                  <button
                    onClick={() => setStep((step + 1) % 4)}
                    className="px-6 py-3 bg-white/20 hover:bg-white/30 rounded-lg font-semibold transition-colors"
                  >
                    →
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {solutions.map((solution, idx) => (
              <div
                key={idx}
                className="bg-gradient-to-br from-green-50 to-white rounded-2xl shadow-md p-8 border-2 border-green-200"
              >
                <div className="w-12 h-12 bg-green-500 rounded-full flex items-center justify-center mb-4 text-white font-bold text-xl">
                  {idx + 1}
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {language === 'en' ? solution.titleEn : solution.titleBn}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {language === 'en' ? solution.descEn : solution.descBn}
                </p>
              </div>
            ))}
          </div>

          <div className="text-center">
            <button
              onClick={onGetStarted}
              className="inline-flex items-center space-x-3 px-12 py-5 bg-green-600 hover:bg-green-700 text-white text-2xl font-bold rounded-full shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300"
            >
              <span>{t('get_started')}</span>
              <ArrowRight className="w-7 h-7" />
            </button>
            <p className="mt-6 text-gray-600 text-lg">
              {language === 'en'
                ? 'Join thousands of farmers protecting their harvest'
                : 'হাজারো কৃষকের সাথে যোগ দিন যারা তাদের ফসল রক্ষা করছেন'}
            </p>
          </div>
        </section>
      </main>

      <style>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fade-in {
          animation: fade-in 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
