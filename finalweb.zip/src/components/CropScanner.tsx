import { useState } from 'react';
import { Camera, Upload, CheckCircle, XCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export function CropScanner() {
  const { language } = useLanguage();
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ status: 'fresh' | 'rotten'; confidence: number } | null>(null);
  const [preview, setPreview] = useState<string | null>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setPreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);

    setLoading(true);
    setResult(null);

    try {
      const mockConfidence = 0.75 + Math.random() * 0.2;
      const mockStatus = Math.random() > 0.3 ? 'fresh' : 'rotten';

      await new Promise((resolve) => setTimeout(resolve, 2000));

      setResult({
        status: mockStatus,
        confidence: mockConfidence,
      });
    } catch (error) {
      console.error('Scanner error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-xl shadow-md p-8">
        <div className="flex items-center space-x-3 mb-6">
          <Camera className="w-8 h-8 text-green-600" />
          <h2 className="text-2xl font-bold text-gray-900">
            {language === 'en' ? 'Crop Health Scanner' : 'ফসল স্বাস্থ্য স্ক্যানার'}
          </h2>
        </div>

        <p className="text-gray-600 mb-6">
          {language === 'en'
            ? 'Upload a photo of your crop to check its health status'
            : 'আপনার ফসলের স্বাস্থ্য পরীক্ষা করতে একটি ছবি আপলোড করুন'}
        </p>

        <div className="border-4 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-green-400 transition-colors">
          <input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
            id="crop-upload"
          />
          <label htmlFor="crop-upload" className="cursor-pointer">
            <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-700 text-lg font-semibold mb-2">
              {language === 'en' ? 'Click to upload photo' : 'ছবি আপলোড করতে ক্লিক করুন'}
            </p>
            <p className="text-gray-500 text-sm">
              {language === 'en' ? 'JPG, PNG, or WEBP (max 5MB)' : 'JPG, PNG, অথবা WEBP (সর্বোচ্চ 5MB)'}
            </p>
          </label>
        </div>

        {preview && (
          <div className="mt-6">
            <img
              src={preview}
              alt="Crop preview"
              className="w-full rounded-lg shadow-md max-h-96 object-contain"
            />
          </div>
        )}

        {loading && (
          <div className="mt-6 text-center">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-4 border-green-600"></div>
            <p className="mt-4 text-gray-600 font-semibold">
              {language === 'en' ? 'Analyzing crop health...' : 'ফসলের স্বাস্থ্য বিশ্লেষণ করা হচ্ছে...'}
            </p>
          </div>
        )}

        {result && !loading && (
          <div className="mt-6">
            <div
              className={`p-6 rounded-xl border-2 ${
                result.status === 'fresh'
                  ? 'bg-green-50 border-green-300'
                  : 'bg-red-50 border-red-300'
              }`}
            >
              <div className="flex items-center space-x-3 mb-4">
                {result.status === 'fresh' ? (
                  <CheckCircle className="w-10 h-10 text-green-600" />
                ) : (
                  <XCircle className="w-10 h-10 text-red-600" />
                )}
                <div>
                  <h3 className="text-2xl font-bold">
                    {result.status === 'fresh'
                      ? (language === 'en' ? 'Fresh & Healthy' : 'তাজা এবং স্বাস্থ্যকর')
                      : (language === 'en' ? 'Damaged/Rotten' : 'ক্ষতিগ্রস্ত/পচা')}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {language === 'en' ? 'Confidence' : 'নিশ্চিততা'}: {Math.round(result.confidence * 100)}%
                  </p>
                </div>
              </div>

              <div className="bg-white p-4 rounded-lg">
                <h4 className="font-semibold mb-2">
                  {language === 'en' ? 'Recommendation' : 'সুপারিশ'}
                </h4>
                {result.status === 'fresh' ? (
                  <p className="text-gray-700">
                    {language === 'en'
                      ? 'Your crop appears healthy. Continue monitoring storage conditions and follow weather advisories.'
                      : 'আপনার ফসল স্বাস্থ্যকর দেখাচ্ছে। সংরক্ষণের অবস্থা পর্যবেক্ষণ চালিয়ে যান এবং আবহাওয়া পরামর্শ অনুসরণ করুন।'}
                  </p>
                ) : (
                  <p className="text-gray-700">
                    {language === 'en'
                      ? 'Immediate action required! Separate affected crops, improve ventilation, and consider quick sale or processing.'
                      : 'তাৎক্ষণিক ব্যবস্থা প্রয়োজন! ক্ষতিগ্রস্ত ফসল আলাদা করুন, বায়ু চলাচল বাড়ান এবং দ্রুত বিক্রয় বা প্রক্রিয়াকরণ বিবেচনা করুন।'}
                  </p>
                )}
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
          <p className="text-sm text-blue-900">
            <strong>{language === 'en' ? 'Note:' : 'নোট:'}</strong>{' '}
            {language === 'en'
              ? 'This is a basic scanner for demonstration. For accurate diagnosis, consult agricultural experts.'
              : 'এটি প্রদর্শনের জন্য একটি মৌলিক স্ক্যানার। সঠিক নির্ণয়ের জন্য কৃষি বিশেষজ্ঞদের পরামর্শ নিন।'}
          </p>
        </div>
      </div>
    </div>
  );
}
