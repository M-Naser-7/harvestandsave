# HarvestGuard Setup Guide

## Quick Start (5 minutes)

### Step 1: Clone and Install
```bash
git clone <your-repo-url>
cd harvestguard
npm install
```

### Step 2: Supabase Setup

1. Create a Supabase account at https://supabase.com
2. Create a new project
3. Go to Project Settings → API
4. Copy your project URL and anon key

### Step 3: Weather API Setup

1. Sign up at https://openweathermap.org/api
2. Get your free API key (2000 calls/day)
3. Wait 10 minutes for activation

### Step 4: Environment Variables

Create `.env` in project root:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
VITE_WEATHER_API_KEY=your_openweather_key_here
```

### Step 5: Database Migration

The database schema is automatically applied through Supabase migrations. The migration file creates:
- All required tables (farmers, crop_batches, weather_cache, risk_assessments, achievements, interventions)
- Row Level Security (RLS) policies
- Indexes for performance

If you need to apply it manually, run the SQL from the migration file in your Supabase SQL Editor.

### Step 6: Run Development Server

```bash
npm run dev
```

Visit http://localhost:5173

## Testing the Application

### Test User Journey

1. **Landing Page**
   - Toggle between English/Bangla
   - View problem statement
   - See solution workflow animation
   - Click "Get Started"

2. **Sign Up**
   - Enter farmer details
   - Choose Division/District/Upazila
   - Create account
   - Earn first achievement badge

3. **Dashboard**
   - View weather forecast for your location
   - See statistics (batches, weight, saved crops)

4. **Add Crop Batch**
   - Select crop type (Paddy)
   - Enter weight and harvest date
   - Choose storage type
   - Submit

5. **View Risk Assessment**
   - Automatic ETCL calculation
   - Risk level indicator
   - Bangla advisory messages
   - Weather-based recommendations

6. **Crop Scanner**
   - Upload crop photo
   - Get health analysis
   - Receive recommendations

7. **Profile & Achievements**
   - View earned badges
   - Export all data as JSON

## Offline Mode

The app saves data to LocalStorage:
- Crop batches cached locally
- Works without internet
- Syncs when connection restored

## Mobile Testing

Test on:
- Chrome DevTools mobile emulation
- Real Android device (4000-5000 Tk phone)
- Slow 3G network throttling

## Deployment Options

### Vercel (Recommended)
```bash
npm run build
vercel --prod
```

### Netlify
```bash
npm run build
netlify deploy --prod --dir=dist
```

### Railway
- Connect GitHub repo
- Set environment variables
- Auto-deploy on push

## Troubleshooting

### Weather API not working?
- Check API key is activated (10 min wait)
- Verify .env file format
- Check browser console for errors
- App uses mock data as fallback

### Database errors?
- Verify Supabase URL and key
- Check RLS policies are enabled
- Ensure migrations ran successfully

### Build errors?
- Run `npm install` again
- Clear node_modules: `rm -rf node_modules && npm install`
- Check Node version: `node --version` (should be 18+)

## Demo Video Recording Tips

Record a 2-minute walkthrough showing:
1. Landing page (10s) - Problem statement in Bangla
2. Sign up (15s) - Create farmer account
3. Add crop (20s) - Register harvest batch
4. Weather widget (15s) - Show 5-day forecast in Bangla
5. Risk assessment (20s) - Display ETCL and advisory
6. Crop scanner (20s) - Upload and analyze photo
7. Achievements (10s) - Show earned badges
8. Data export (10s) - Download JSON

Keep it smooth, show the Bangla UI, and highlight the problem-solving aspects!

## Support

For issues, check:
- Console errors (F12 in browser)
- Network tab for API failures
- Supabase logs
- GitHub issues

## Production Checklist

Before deploying:
- [ ] Environment variables set
- [ ] Database migrations applied
- [ ] Weather API key working
- [ ] Build succeeds (`npm run build`)
- [ ] Mobile responsive checked
- [ ] Bangla text displays correctly
- [ ] Offline mode tested
- [ ] Data export works

Good luck with your hackathon! 🚀
