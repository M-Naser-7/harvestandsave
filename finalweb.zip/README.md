# HarvestGuard - Food Loss Prevention System for Bangladesh

A tech solution to reduce food loss in Bangladesh by providing farmers with real-time monitoring, weather forecasting, risk assessment, and actionable advisories in Bangla.

## Problem Statement

Bangladesh loses approximately 4.5 million metric tonnes of food grains annually, worth $1.5 billion, due to inadequate storage, poor handling, and inefficient transportation. This project addresses SDG 12.3: reducing food losses along production and supply chains.

## Features Implemented

### ✅ A1: Storytelling Landing Page
- Bilingual (Bangla/English) problem narrative
- Interactive solution demonstration with CSS animations
- Visual workflow: Data → Warning → Action → Saved Food
- Mobile-first design with fast load times

### ✅ A2: Farmer and Crop Management
- Secure email/password authentication via Supabase
- Farmer profile with bilingual support
- Crop batch registration (Paddy/Rice)
- Achievement badges system
- Offline mode with LocalStorage sync
- Data export as JSON

### ✅ A3: Hyper-Local Weather Integration
- Live weather data based on Upazila
- 5-day forecast with temperature, humidity, rain chance
- Bangla UI and advisories
- Example: "আগামী ৩ দিন বৃষ্টি ৮৫% → আজই ধান কাটুন"

### ✅ A4: Risk Prediction & Forecasting
- ETCL (Estimated Time to Critical Loss) calculation
- Weather-integrated risk assessment
- Risk levels: Low, Medium, High, Critical
- Bangla and English advisories

### ✅ A5: Basic Crop Health Scanner
- Photo upload for crop analysis
- Mock AI integration (ready for HuggingFace API)
- Fresh vs. Rotten detection
- Mobile-optimized interface

## Tech Stack

- **Frontend**: React 18, TypeScript, Tailwind CSS, Vite
- **Database**: Supabase (PostgreSQL with RLS)
- **Authentication**: Supabase Auth (email/password)
- **Weather API**: OpenWeatherMap
- **Offline**: LocalStorage with sync
- **Icons**: Lucide React

## Environment Setup

Create a `.env` file in the project root:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_WEATHER_API_KEY=your_openweather_api_key
```

## Installation

```bash
npm install
npm run dev
```

## Database Schema

The application uses the following tables:
- `farmers` - User profiles with location data
- `crop_batches` - Harvested crop tracking
- `weather_cache` - Cached weather forecasts
- `risk_assessments` - ETCL calculations and advisories
- `achievements` - Gamification badges
- `interventions` - Farmer actions and outcomes

All tables have Row Level Security (RLS) enabled.

## Features by Requirement

| Requirement | Status | Description |
|------------|--------|-------------|
| A1 - Landing Page | ✅ | Bilingual storytelling with animations |
| A2 - Farmer Management | ✅ | Registration, profiles, batches, badges, offline mode |
| A3 - Weather Integration | ✅ | 5-day forecast with Bangla advisories |
| A4 - Risk Prediction | ✅ | ETCL calculation with weather factors |
| A5 - Crop Scanner | ✅ | Photo upload with mock AI analysis |

## Mobile Optimization

- Large touch targets (min 44x44px)
- High contrast text for readability
- Optimized for 4000-5000 Tk Android phones
- Offline-first architecture
- Fast load times (<3s on 3G)

## Gamification

Farmers earn badges for:
- First crop registration
- First batch logged
- Successful interventions
- Consistent monitoring

## Bangla Language Support

- Complete UI translation
- Bangla numerals in weather widget
- Culturally appropriate advisories
- Date formatting in Bengali calendar

## Data Export

Farmers can export all their data as JSON including:
- Profile information
- Crop batches
- Risk assessments
- Achievements
- Historical interventions

## Future Enhancements

- SMS notifications via Twilio
- Real HuggingFace AI model integration
- Marketplace integration for quick sales
- Community features for knowledge sharing
- Voice input in Bangla
- Pest identification

## Contributing

This project was built for the HarvestGuard Hackathon to address food loss in Bangladesh and support SDG 12.3.

## License

MIT
