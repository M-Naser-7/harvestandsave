# HarvestGuard - Quick Start Guide

## 🚀 5-Minute Setup

### 1. Install Dependencies
```bash
npm install
```

### 2. Create Environment File
Create `.env` in project root:
```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_WEATHER_API_KEY=your_openweather_api_key
```

### 3. Setup Supabase
1. Go to https://supabase.com and create project
2. Copy URL and anon key from Project Settings → API
3. Apply migration SQL (see migration file in project)

### 4. Get Weather API Key
1. Sign up at https://openweathermap.org/api
2. Get free API key
3. Wait 10 minutes for activation

### 5. Run Development Server
```bash
npm run dev
```

Visit http://localhost:5173

## ✅ Verify Setup

### Test 1: Landing Page
- Open browser
- See landing page with problem statement
- Toggle language (EN ↔ BN)

### Test 2: Sign Up
- Click "শুরু করুন"
- Create account with Bangla name
- See dashboard

### Test 3: Weather
- Weather widget shows 5-day forecast
- Bangla numerals display: ৩২°C

### Test 4: Add Crop
- Click "নতুন ফসল যোগ করুন"
- Fill form and submit
- See risk assessment

## 📦 Build for Production
```bash
npm run build
```

## 🚀 Deploy to Vercel
```bash
npm i -g vercel
vercel
```

Add environment variables in Vercel dashboard, then:
```bash
vercel --prod
```

## 📚 Full Documentation
- **README.md** - Project overview
- **SETUP_GUIDE.md** - Detailed setup
- **PROJECT_SUMMARY.md** - Complete feature list
- **DEPLOYMENT_CHECKLIST.md** - Production deployment
- **VIDEO_DEMO_SCRIPT.md** - Demo recording guide

## 🐛 Troubleshooting

**Weather not loading?**
- Wait 10 minutes after API key generation
- Check .env file exists and has correct variable name
- App uses mock data as fallback

**Database errors?**
- Verify Supabase credentials
- Check migration was applied
- Confirm RLS is enabled

**Build fails?**
- Run `npm install` again
- Check Node version (need 18+)
- Run `npm run typecheck`

## 📞 Need Help?

Check the detailed guides:
1. SETUP_GUIDE.md for installation issues
2. DEPLOYMENT_CHECKLIST.md for deployment
3. PROJECT_SUMMARY.md for feature documentation

## 🎯 All Core Features

✅ A1: Storytelling Landing Page (Bilingual)
✅ A2: Farmer & Crop Management (Offline mode)
✅ A3: Weather Integration (Bangla UI)
✅ A4: Risk Prediction (ETCL calculation)
✅ A5: Crop Health Scanner (AI-ready)

**Bonus:** Gamification, CSV/JSON export, Achievement badges

Ready to save Bangladesh's harvest! 🌾
