# HarvestGuard - 2-Minute Video Demo Script

## 🎬 Recording Tips
- Screen resolution: 1920x1080 or 1280x720
- Use mobile responsive view (375px width) in Chrome DevTools
- Record at 30fps minimum
- Clear audio, speak slowly
- Show Bangla UI prominently

## 📝 Script (120 seconds)

### Opening (0:00-0:10) - 10 seconds
**[Show Landing Page]**

*"Bangladesh loses 4.5 million tonnes of food grains every year worth $1.5 billion. HarvestGuard solves this crisis."*

**Action:**
- Open landing page
- Scroll through problem statistics
- Show bilingual toggle (English ↔ Bangla)

---

### Problem & Solution (0:10-0:25) - 15 seconds
**[Scroll through landing page]**

*"Our storytelling interface explains the crisis clearly in both Bangla and English. Farmers see how real-time monitoring, early warnings, and smart advisories can save their harvest."*

**Action:**
- Show the 4-step solution workflow animation
- Click through the interactive demo (Data → Warning → Action → Save)
- Highlight Bangla text

---

### Registration (0:25-0:40) - 15 seconds
**[Click "Get Started" → Sign Up]**

*"Let me create a farmer account. I enter my name, phone, location down to the Upazila level, and create a secure password."*

**Action:**
- Fill registration form:
  - Name: "করিম আহমেদ" (Karim Ahmed)
  - Email: demo@example.com
  - Phone: 01712345678
  - Division: Dhaka
  - District: Dhaka
  - Upazila: Savar
- Click "নিবন্ধন করুন" (Sign Up)

---

### Dashboard & Weather (0:40-0:55) - 15 seconds
**[Dashboard loads]**

*"The dashboard is in full Bangla. Here's the weather forecast for Dhaka showing temperature, humidity, and rain chance for the next 5 days - all in Bengali numerals."*

**Action:**
- Show dashboard statistics (0 active batches initially)
- Point to Weather Widget
- Highlight Bangla numerals: ৩২°C, ৭৫%, ৪০%
- Show today's forecast card

---

### Adding Crop Batch (0:55-1:15) - 20 seconds
**[Navigate to "নতুন ফসল যোগ করুন"]**

*"I register a new paddy harvest. I enter 500 kilograms, today's date, and select my storage type - jute bag. Once submitted, the system immediately calculates risk."*

**Action:**
- Click "নতুন ফসল যোগ করুন" (Add New Crop)
- Fill form:
  - Crop: ধান/চাল (Paddy/Rice)
  - Weight: 500 kg
  - Harvest Date: Today
  - Storage: পাটের বস্তায় (Jute Bag)
- Click "সংরক্ষণ করুন" (Save)

---

### Risk Assessment (1:15-1:35) - 20 seconds
**[View created batch with risk card]**

*"Here's the magic! The system calculated an ETCL - Estimated Time to Critical Loss - of 28 days. Risk level is LOW right now. But look at this Bangla advisory..."*

**Action:**
- Show crop batch card with green "কম" (Low) risk indicator
- Point to ETCL: "28 দিন"
- Read advisory aloud (in Bangla):
  *"আবহাওয়া অনুকূল। নিয়মিত ফসল পরীক্ষা করুন..."*
- Show how risk changes with weather conditions

---

### Crop Scanner (1:35-1:50) - 15 seconds
**[Navigate to Scanner]**

*"The crop health scanner uses AI. I upload a photo, and in seconds it tells me if my crop is fresh or damaged, with specific recommendations."*

**Action:**
- Click "ফসল স্ক্যানার" (Crop Scanner)
- Upload sample crop image
- Show loading animation
- Display result: "তাজা এবং স্বাস্থ্যকর" (Fresh & Healthy) with 92% confidence
- Show recommendation text

---

### Achievements & Export (1:50-2:05) - 15 seconds
**[Navigate to Profile]**

*"Farmers earn achievement badges for protecting their crops. All data can be exported as CSV or JSON for record-keeping and analysis."*

**Action:**
- Click "প্রোফাইল" (Profile)
- Show achievement badge: "প্রথম ফসল নিবন্ধিত"
- Click "CSV রপ্তানি" button
- Show file downloading

---

### Closing (2:05-2:10) - 5 seconds
**[Back to Dashboard]**

*"HarvestGuard - protecting Bangladesh's harvest with technology. Saving food, saving livelihoods, achieving SDG 12.3."*

**Action:**
- Quick pan across dashboard
- Fade to "HarvestGuard" logo/title screen

---

## 🎯 Key Points to Emphasize

1. **Bilingual Interface** - Show Bangla prominently
2. **Mobile-Friendly** - Use mobile view
3. **Real Problem** - Mention the $1.5B loss
4. **Smart Solution** - Highlight ETCL calculation
5. **Easy to Use** - Show simple workflows
6. **Offline Ready** - Mention LocalStorage (don't need to show)
7. **Data Export** - Demonstrate CSV download
8. **SDG 12.3** - Connect to UN goal

## 📊 Optional: Show These Stats On-Screen

- "4.5M tonnes lost annually"
- "$1.5B economic impact"
- "12-32% food waste"
- "SDG 12.3 Target"

## 🎨 Visual Tips

1. Keep cursor movements smooth
2. Use zoom in (Ctrl +) for better visibility
3. Pause briefly on important screens
4. Use annotations/arrows if tool allows
5. Clear, professional voiceover
6. Background music (optional, low volume)

## ✅ Pre-Recording Checklist

- [ ] Create demo farmer account beforehand
- [ ] Prepare sample crop images
- [ ] Test all features work smoothly
- [ ] Check Bangla text renders correctly
- [ ] Verify weather API is responding
- [ ] Practice the full script 2-3 times
- [ ] Time yourself (should be under 2:10)
- [ ] Close unnecessary browser tabs
- [ ] Hide personal information
- [ ] Use incognito/clean browser session

## 🎬 Recording Tools

**Recommended:**
- OBS Studio (Free, professional)
- Loom (Easy, cloud-hosted)
- QuickTime (Mac built-in)
- Windows Game Bar (Win + G)

**Video Specs:**
- Format: MP4 or MOV
- Resolution: 1080p preferred, 720p minimum
- Max file size: Usually 100MB for uploads
- Frame rate: 30fps minimum

Good luck with your demo! 🚀
